import type { AppState } from '@/types';

const STORAGE_KEY = 'medicoshare:v1';

export const emptyState: AppState = {
  currentUserId: null,
  profiles: [],
  posts: [],
  comments: [],
  follows: [],
  reports: [],
};

export function loadState(): AppState {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return emptyState;
    return { ...emptyState, ...(JSON.parse(raw) as Partial<AppState>) };
  } catch {
    return emptyState;
  }
}

export function saveState(state: AppState): boolean {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    return true;
  } catch {
    return false;
  }
}
