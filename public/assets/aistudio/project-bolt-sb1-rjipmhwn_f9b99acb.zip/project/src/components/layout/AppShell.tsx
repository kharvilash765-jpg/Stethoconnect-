import { AlertTriangle, Home, Rss, Stethoscope, User, Users } from 'lucide-react';
import type { ReactNode } from 'react';
import type { Route } from '@/hooks/useRoute';
import { useStore } from '@/store/useStore';
import { Avatar } from '@/components/common/Avatar';

const NAV_ITEMS = [
  { label: 'Home', href: '#/', icon: Home, match: (r: Route) => r.name === 'home' || r.name === 'post' },
  { label: 'Following', href: '#/following', icon: Rss, match: (r: Route) => r.name === 'following' },
  { label: 'People', href: '#/people', icon: Users, match: (r: Route) => r.name === 'people' },
] as const;

interface AppShellProps {
  route: Route;
  children: ReactNode;
}

export function AppShell({ route, children }: AppShellProps) {
  const { state, storageError } = useStore();
  const me = state.profiles.find((p) => p.id === state.currentUserId);
  const isOwnProfileRoute = route.name === 'profile' && route.userId === me?.id;
  const myProfileHref = `#/profile/${me?.id ?? ''}`;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <header className="sticky top-0 z-30 border-b border-slate-200/80 bg-white/90 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-5xl items-center justify-between gap-4 px-4 sm:px-6">
          <a href="#/" className="flex items-center gap-2.5">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-teal-600 text-white">
              <Stethoscope className="h-5 w-5" />
            </span>
            <span className="text-lg font-semibold tracking-tight text-slate-900">Medicoshare</span>
          </a>

          <nav className="hidden items-center gap-1 md:flex" aria-label="Main">
            {NAV_ITEMS.map((item) => {
              const active = item.match(route);
              return (
                <a
                  key={item.label}
                  href={item.href}
                  className={`flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium transition ${
                    active ? 'bg-teal-50 text-teal-700' : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                  }`}
                >
                  <item.icon className="h-4 w-4" />
                  {item.label}
                </a>
              );
            })}
            <a
              href={myProfileHref}
              className={`ml-2 flex items-center gap-2 rounded-full py-1 pl-1 pr-4 text-sm font-medium transition ${
                isOwnProfileRoute ? 'bg-teal-50 text-teal-700' : 'text-slate-700 hover:bg-slate-100'
              }`}
            >
              {me && <Avatar name={me.name} seed={me.id} size="sm" />}
              My profile
            </a>
          </nav>

          <a href={myProfileHref} className="md:hidden" aria-label="My profile">
            {me && <Avatar name={me.name} seed={me.id} size="sm" />}
          </a>
        </div>
      </header>

      {storageError && (
        <div className="border-b border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">
          <div className="mx-auto flex max-w-5xl items-start gap-2 sm:px-2">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
            <span>
              Browser storage is full, so recent changes may not be saved. Delete some posts or images to free up space.
            </span>
          </div>
        </div>
      )}

      <main className="mx-auto max-w-2xl px-4 pb-28 pt-6 sm:px-6 md:pb-16">{children}</main>

      <nav
        className="fixed inset-x-0 bottom-0 z-30 border-t border-slate-200 bg-white/95 backdrop-blur md:hidden"
        aria-label="Main mobile"
      >
        <div className="mx-auto grid max-w-md grid-cols-4 px-2 pb-[max(env(safe-area-inset-bottom),0.5rem)] pt-2">
          {NAV_ITEMS.map((item) => {
            const active = item.match(route);
            return (
              <a
                key={item.label}
                href={item.href}
                className={`flex flex-col items-center gap-1 rounded-xl py-1.5 text-[11px] font-medium transition ${
                  active ? 'text-teal-700' : 'text-slate-500'
                }`}
              >
                <item.icon className={`h-5 w-5 ${active ? 'stroke-[2.5]' : ''}`} />
                {item.label}
              </a>
            );
          })}
          <a
            href={myProfileHref}
            className={`flex flex-col items-center gap-1 rounded-xl py-1.5 text-[11px] font-medium transition ${
              isOwnProfileRoute ? 'text-teal-700' : 'text-slate-500'
            }`}
          >
            <User className={`h-5 w-5 ${isOwnProfileRoute ? 'stroke-[2.5]' : ''}`} />
            Profile
          </a>
        </div>
      </nav>
    </div>
  );
}
