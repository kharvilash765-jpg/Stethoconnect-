import { useState, type FormEvent } from 'react';
import { Stethoscope } from 'lucide-react';
import { useStore } from '@/store/useStore';
import { Avatar } from '@/components/common/Avatar';

const HANDLE_PATTERN = /^[a-z0-9_]{3,20}$/;

export function Onboarding() {
  const { state, dispatch } = useStore();
  const [name, setName] = useState('');
  const [handle, setHandle] = useState('');
  const [bio, setBio] = useState('');
  const [error, setError] = useState<string | null>(null);

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const cleanHandle = handle.trim().replace(/^@/, '').toLowerCase();
    if (!name.trim()) return setError('Please enter your name.');
    if (!HANDLE_PATTERN.test(cleanHandle)) {
      return setError('Username must be 3-20 characters: letters, numbers or underscore.');
    }
    if (state.profiles.some((p) => p.handle === cleanHandle)) {
      return setError('This username is already taken. Try another one.');
    }
    setError(null);
    dispatch({ type: 'profile/create', name, handle: cleanHandle, bio });
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-teal-50 via-white to-sky-50 px-4 py-10">
      <div className="w-full max-w-md animate-fade-up">
        <div className="mb-8 flex flex-col items-center text-center">
          <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-teal-600 text-white shadow-lg shadow-teal-600/20">
            <Stethoscope className="h-7 w-7" />
          </div>
          <h1 className="text-3xl font-semibold leading-[1.2] text-slate-900">Medicoshare</h1>
          <p className="mt-2 text-base leading-normal text-slate-600">
            Share health knowledge, learn from others and stay connected.
          </p>
        </div>

        {state.profiles.length > 0 && (
          <div className="mb-6 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
            <p className="mb-3 text-sm font-medium text-slate-700">Continue as</p>
            <ul className="space-y-2">
              {state.profiles.map((p) => (
                <li key={p.id}>
                  <button
                    type="button"
                    onClick={() => dispatch({ type: 'session/set', userId: p.id })}
                    className="flex w-full items-center gap-3 rounded-xl px-3 py-2 text-left transition hover:bg-teal-50"
                  >
                    <Avatar name={p.name} seed={p.id} size="sm" />
                    <span className="min-w-0">
                      <span className="block truncate text-sm font-medium text-slate-900">{p.name}</span>
                      <span className="block truncate text-xs text-slate-500">@{p.handle}</span>
                    </span>
                  </button>
                </li>
              ))}
            </ul>
            <div className="my-4 flex items-center gap-3 text-xs text-slate-400">
              <span className="h-px flex-1 bg-slate-200" />
              or create new
              <span className="h-px flex-1 bg-slate-200" />
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
          <label className="block">
            <span className="mb-1.5 block text-sm font-medium text-slate-700">Your name</span>
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              maxLength={60}
              placeholder="Dr. Asha Verma"
              className="w-full rounded-xl border border-slate-300 px-4 py-2.5 text-slate-900 placeholder:text-slate-400 focus:border-teal-500 focus:outline-none focus:ring-4 focus:ring-teal-500/15"
            />
          </label>
          <label className="block">
            <span className="mb-1.5 block text-sm font-medium text-slate-700">Username</span>
            <input
              value={handle}
              onChange={(e) => setHandle(e.target.value)}
              maxLength={21}
              placeholder="ashaverma"
              className="w-full rounded-xl border border-slate-300 px-4 py-2.5 text-slate-900 placeholder:text-slate-400 focus:border-teal-500 focus:outline-none focus:ring-4 focus:ring-teal-500/15"
            />
          </label>
          <label className="block">
            <span className="mb-1.5 block text-sm font-medium text-slate-700">Bio (optional)</span>
            <textarea
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              maxLength={160}
              rows={3}
              placeholder="Cardiologist, sharing simple heart-health tips"
              className="w-full resize-none rounded-xl border border-slate-300 px-4 py-2.5 text-slate-900 placeholder:text-slate-400 focus:border-teal-500 focus:outline-none focus:ring-4 focus:ring-teal-500/15"
            />
          </label>
          {error && <p className="text-sm text-rose-600">{error}</p>}
          <button
            type="submit"
            className="w-full rounded-xl bg-teal-600 px-4 py-3 font-medium text-white shadow-sm transition hover:bg-teal-700 active:scale-[0.99]"
          >
            Create profile
          </button>
        </form>
      </div>
    </div>
  );
}
