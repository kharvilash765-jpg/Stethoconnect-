import { useState } from 'react';
import { Modal } from '@/components/common/Modal';
import type { ReportReason } from '@/types';
import { useStore } from '@/store/useStore';

const REASONS: { value: ReportReason; label: string; hint: string }[] = [
  { value: 'misinformation', label: 'Medical misinformation', hint: 'Unsafe or false health claims' },
  { value: 'harassment', label: 'Harassment or hate', hint: 'Insults, threats or targeting people' },
  { value: 'spam', label: 'Spam or advertising', hint: 'Promotions or repeated content' },
  { value: 'inappropriate', label: 'Inappropriate content', hint: 'Graphic or offensive material' },
  { value: 'other', label: 'Something else', hint: 'Any other concern' },
];

interface ReportModalProps {
  postId: string;
  onClose: () => void;
}

export function ReportModal({ postId, onClose }: ReportModalProps) {
  const { dispatch } = useStore();
  const [reason, setReason] = useState<ReportReason | null>(null);
  const [submitted, setSubmitted] = useState(false);

  function submit() {
    if (!reason) return;
    dispatch({ type: 'post/report', postId, reason });
    setSubmitted(true);
  }

  if (submitted) {
    return (
      <Modal title="Report post" onClose={onClose}>
        <div className="py-4 text-center">
          <p className="font-semibold text-slate-900">Thanks for reporting</p>
          <p className="mt-2 text-sm leading-normal text-slate-600">
            Our team reviews reports. This post is now hidden from your feed.
          </p>
          <button
            type="button"
            onClick={onClose}
            className="mt-5 rounded-xl bg-slate-900 px-5 py-2.5 text-sm font-medium text-white transition hover:bg-slate-800"
          >
            Done
          </button>
        </div>
      </Modal>
    );
  }

  return (
    <Modal title="Report post" onClose={onClose}>
      <p className="mb-4 text-sm leading-normal text-slate-600">Why are you reporting this post?</p>
      <fieldset className="space-y-2">
        <legend className="sr-only">Reason</legend>
        {REASONS.map((r) => (
          <label
            key={r.value}
            className={`flex cursor-pointer items-start gap-3 rounded-xl border p-3 transition ${
              reason === r.value ? 'border-teal-500 bg-teal-50' : 'border-slate-200 hover:bg-slate-50'
            }`}
          >
            <input
              type="radio"
              name="report-reason"
              value={r.value}
              checked={reason === r.value}
              onChange={() => setReason(r.value)}
              className="mt-1 h-4 w-4 accent-teal-600"
            />
            <span>
              <span className="block text-sm font-medium text-slate-900">{r.label}</span>
              <span className="block text-xs text-slate-500">{r.hint}</span>
            </span>
          </label>
        ))}
      </fieldset>
      <button
        type="button"
        onClick={submit}
        disabled={!reason}
        className="mt-5 w-full rounded-xl bg-rose-600 px-4 py-2.5 text-sm font-medium text-white transition hover:bg-rose-700 disabled:cursor-not-allowed disabled:bg-slate-300"
      >
        Submit report
      </button>
    </Modal>
  );
}
