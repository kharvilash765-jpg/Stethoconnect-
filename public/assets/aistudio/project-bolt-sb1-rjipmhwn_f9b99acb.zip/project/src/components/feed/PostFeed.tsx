import type { ReactNode } from 'react';
import { PostCard } from '@/components/feed/PostCard';
import type { Post } from '@/types';

interface PostFeedProps {
  posts: Post[];
  emptyTitle: string;
  emptyText: string;
  emptyAction?: ReactNode;
}

export function PostFeed({ posts, emptyTitle, emptyText, emptyAction }: PostFeedProps) {
  if (posts.length === 0) {
    return (
      <div className="animate-fade-up rounded-2xl border border-dashed border-slate-300 bg-white px-6 py-12 text-center">
        <p className="font-semibold text-slate-900">{emptyTitle}</p>
        <p className="mx-auto mt-2 max-w-sm text-sm leading-normal text-slate-600">{emptyText}</p>
        {emptyAction && <div className="mt-5">{emptyAction}</div>}
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {posts.map((post) => (
        <PostCard key={post.id} post={post} />
      ))}
    </div>
  );
}
