import { useRef, useState, type ChangeEvent } from 'react';
import { ImagePlus, Loader2, Send, X } from 'lucide-react';
import { compressImage } from '@/lib/images';
import { MAX_POST_IMAGES, MAX_POST_LENGTH } from '@/types';
import { useStore } from '@/store/useStore';
import { Avatar } from '@/components/common/Avatar';

export function Composer() {
  const { state, dispatch } = useStore();
  const me = state.profiles.find((p) => p.id === state.currentUserId);
  const [text, setText] = useState('');
  const [images, setImages] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  if (!me) return null;

  const canPost = !busy && (text.trim().length > 0 || images.length > 0);

  async function handleFiles(e: ChangeEvent<HTMLInputElement>) {
    const remaining = MAX_POST_IMAGES - images.length;
    const files = Array.from(e.target.files ?? [])
      .filter((f) => f.type.startsWith('image/'))
      .slice(0, remaining);
    e.target.value = '';
    if (files.length === 0) return;

    setBusy(true);
    setError(null);
    try {
      const encoded = await Promise.all(files.map(compressImage));
      setImages((prev) => [...prev, ...encoded].slice(0, MAX_POST_IMAGES));
    } catch {
      setError('Some images could not be read. Please try different files.');
    } finally {
      setBusy(false);
    }
  }

  function submit() {
    if (!canPost) return;
    dispatch({ type: 'post/create', text, images });
    setText('');
    setImages([]);
    setError(null);
  }

  return (
    <section className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm transition focus-within:border-teal-300 focus-within:shadow-md sm:p-5">
      <div className="flex gap-3">
        <Avatar name={me.name} seed={me.id} />
        <div className="min-w-0 flex-1">
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            maxLength={MAX_POST_LENGTH}
            rows={3}
            placeholder="What health tip or experience would you like to share?"
            aria-label="Write a post"
            className="w-full resize-none border-none bg-transparent p-0 text-base leading-normal text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-0"
          />

          {images.length > 0 && (
            <ul className="mt-3 grid grid-cols-3 gap-2 sm:grid-cols-5">
              {images.map((src, i) => (
                <li key={i} className="group relative aspect-square overflow-hidden rounded-xl bg-slate-100">
                  <img src={src} alt={`Attachment ${i + 1}`} className="h-full w-full object-cover" />
                  <button
                    type="button"
                    onClick={() => setImages((prev) => prev.filter((_, idx) => idx !== i))}
                    aria-label="Remove image"
                    className="absolute right-1.5 top-1.5 rounded-full bg-slate-900/70 p-1 text-white transition hover:bg-slate-900"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                </li>
              ))}
            </ul>
          )}

          {error && <p className="mt-2 text-sm text-rose-600">{error}</p>}

          <div className="mt-4 flex items-center justify-between gap-3 border-t border-slate-100 pt-3">
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => fileRef.current?.click()}
                disabled={busy || images.length >= MAX_POST_IMAGES}
                className="flex items-center gap-2 rounded-full px-3 py-1.5 text-sm font-medium text-teal-700 transition hover:bg-teal-50 disabled:cursor-not-allowed disabled:text-slate-400 disabled:hover:bg-transparent"
              >
                {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <ImagePlus className="h-4 w-4" />}
                {images.length >= MAX_POST_IMAGES ? 'Max 5 images' : `Photos ${images.length}/${MAX_POST_IMAGES}`}
              </button>
              <input
                ref={fileRef}
                type="file"
                accept="image/*"
                multiple
                onChange={handleFiles}
                className="hidden"
              />
              <span className="hidden text-xs text-slate-400 sm:inline">
                {text.length}/{MAX_POST_LENGTH}
              </span>
            </div>
            <button
              type="button"
              onClick={submit}
              disabled={!canPost}
              className="flex items-center gap-2 rounded-full bg-teal-600 px-5 py-2 text-sm font-medium text-white shadow-sm transition hover:bg-teal-700 active:scale-95 disabled:cursor-not-allowed disabled:bg-slate-300"
            >
              <Send className="h-4 w-4" />
              Post
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
