import { useEffect, useState } from 'react';
import { Eye, Flag, MessageCircle, ThumbsDown, ThumbsUp, Trash2 } from 'lucide-react';
import type { Post } from '@/types';
import { formatCount, timeAgo } from '@/lib/format';
import { useStore } from '@/store/useStore';
import { Avatar } from '@/components/common/Avatar';
import { ImageGrid } from '@/components/feed/ImageGrid';
import { ReportModal } from '@/components/feed/ReportModal';

interface PostCardProps {
  post: Post;
}

export function PostCard({ post }: PostCardProps) {
  const { state, dispatch } = useStore();
  const [reportOpen, setReportOpen] = useState(false);
  const [revealed, setRevealed] = useState(false);
  const me = state.currentUserId;
  const author = state.profiles.find((p) => p.id === post.authorId);

  useEffect(() => {
    if (me && me !== post.authorId) dispatch({ type: 'post/view', postId: post.id });
  }, [dispatch, me, post.id, post.authorId]);

  const isOwn = me === post.authorId;
  const myReaction = me ? post.reactions[me] : undefined;
  const likeCount = Object.values(post.reactions).filter((r) => r === 'like').length;
  const dislikeCount = Object.values(post.reactions).filter((r) => r === 'dislike').length;
  const commentCount = state.comments.filter((c) => c.postId === post.id).length;
  const reportedByMe = state.reports.some((r) => r.postId === post.id && r.reporterId === me);
  const hidden = reportedByMe && !revealed;

  if (!author) return null;

  function handleDelete() {
    if (window.confirm('Delete this post? This cannot be undone.')) {
      dispatch({ type: 'post/delete', postId: post.id });
    }
  }

  const reactionClass = (active: boolean) =>
    `flex items-center gap-1.5 rounded-full px-3 py-1.5 text-sm font-medium transition active:scale-95 ${
      active ? 'bg-teal-50 text-teal-700' : 'text-slate-600 hover:bg-slate-100'
    }`;

  return (
    <article className="animate-fade-up rounded-2xl border border-slate-200 bg-white p-4 shadow-sm transition hover:shadow-md sm:p-5">
      <header className="flex items-start gap-3">
        <a href={`#/profile/${author.id}`} aria-label={`View ${author.name}'s profile`}>
          <Avatar name={author.name} seed={author.id} />
        </a>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-baseline gap-x-2">
            <a href={`#/profile/${author.id}`} className="truncate font-semibold text-slate-900 hover:underline">
              {author.name}
            </a>
            <span className="truncate text-sm text-slate-500">@{author.handle}</span>
            <span className="text-sm text-slate-400">·</span>
            <a href={`#/post/${post.id}`} className="text-sm text-slate-500 hover:text-teal-700 hover:underline">
              {timeAgo(post.createdAt)}
            </a>
          </div>

          {hidden ? (
            <div className="mt-2 flex flex-wrap items-center justify-between gap-3 rounded-xl bg-slate-50 px-4 py-3">
              <p className="text-sm text-slate-600">You reported this post. It is hidden from your feed.</p>
              <button
                type="button"
                onClick={() => setRevealed(true)}
                className="text-sm font-medium text-teal-700 hover:underline"
              >
                Show anyway
              </button>
            </div>
          ) : (
            <>
              {post.text && (
                <p className="mt-1.5 whitespace-pre-line break-words text-[15px] leading-normal text-slate-800">
                  {post.text}
                </p>
              )}
              <ImageGrid images={post.images} alt={`Post by ${author.name}`} />

              <footer className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-slate-100 pt-2">
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => me && dispatch({ type: 'post/react', postId: post.id, reaction: 'like' })}
                    disabled={!me}
                    aria-pressed={myReaction === 'like'}
                    aria-label="Like"
                    className={reactionClass(myReaction === 'like')}
                  >
                    <ThumbsUp className={`h-4 w-4 ${myReaction === 'like' ? 'fill-current' : ''}`} />
                    {formatCount(likeCount)}
                  </button>
                  <button
                    type="button"
                    onClick={() => me && dispatch({ type: 'post/react', postId: post.id, reaction: 'dislike' })}
                    disabled={!me}
                    aria-pressed={myReaction === 'dislike'}
                    aria-label="Dislike"
                    className={reactionClass(myReaction === 'dislike')}
                  >
                    <ThumbsDown className={`h-4 w-4 ${myReaction === 'dislike' ? 'fill-current' : ''}`} />
                    {formatCount(dislikeCount)}
                  </button>
                  <a
                    href={`#/post/${post.id}`}
                    className="flex items-center gap-1.5 rounded-full px-3 py-1.5 text-sm font-medium text-slate-600 transition hover:bg-slate-100"
                  >
                    <MessageCircle className="h-4 w-4" />
                    {formatCount(commentCount)}
                  </a>
                  <span className="flex items-center gap-1.5 px-2 text-sm text-slate-500" title="Reach (unique views)">
                    <Eye className="h-4 w-4" />
                    {formatCount(post.viewers.length)}
                  </span>
                </div>

                <div className="flex items-center gap-1">
                  {isOwn ? (
                    <button
                      type="button"
                      onClick={handleDelete}
                      aria-label="Delete post"
                      className="rounded-full p-2 text-slate-400 transition hover:bg-rose-50 hover:text-rose-600"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  ) : (
                    me && (
                      <button
                        type="button"
                        onClick={() => setReportOpen(true)}
                        className="flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium text-slate-500 transition hover:bg-rose-50 hover:text-rose-600"
                      >
                        <Flag className="h-3.5 w-3.5" />
                        Report
                      </button>
                    )
                  )}
                </div>
              </footer>
            </>
          )}
        </div>
      </header>

      {reportOpen && <ReportModal postId={post.id} onClose={() => setReportOpen(false)} />}
    </article>
  );
}
