import type { ReactNode } from 'react';
import { formatCount } from '@/lib/format';
import type { Profile } from '@/types';
import { Avatar } from '@/components/common/Avatar';

interface ProfileHeaderProps {
  profile: Profile;
  stats: { posts: number; followers: number; following: number; reach: number };
  actions: ReactNode;
}

const STAT_LABELS: { key: 'posts' | 'followers' | 'following' | 'reach'; label: string }[] = [
  { key: 'posts', label: 'Posts' },
  { key: 'followers', label: 'Followers' },
  { key: 'following', label: 'Following' },
  { key: 'reach', label: 'Reach' },
];

export function ProfileHeader({ profile, stats, actions }: ProfileHeaderProps) {
  return (
    <section className="animate-fade-up rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-7">
      <div className="flex flex-col items-center text-center sm:flex-row sm:items-start sm:text-left">
        <Avatar name={profile.name} seed={profile.id} size="lg" />
        <div className="mt-4 min-w-0 flex-1 sm:ml-6 sm:mt-1">
          <h1 className="text-2xl font-semibold leading-[1.2] text-slate-900">{profile.name}</h1>
          <p className="text-sm text-slate-500">@{profile.handle}</p>
          {profile.bio && (
            <p className="mx-auto mt-3 max-w-md text-sm leading-normal text-slate-700 sm:mx-0">{profile.bio}</p>
          )}
          <div className="mt-4 flex flex-wrap justify-center gap-2 sm:justify-start">{actions}</div>
        </div>
      </div>

      <dl className="mt-6 grid grid-cols-4 divide-x divide-slate-100 rounded-xl bg-slate-50">
        {STAT_LABELS.map((s) => (
          <div key={s.key} className="px-2 py-3 text-center">
            <dt className="text-xs text-slate-500">{s.label}</dt>
            <dd className="mt-0.5 text-lg font-semibold text-slate-900">{formatCount(stats[s.key])}</dd>
          </div>
        ))}
      </dl>
    </section>
  );
}
