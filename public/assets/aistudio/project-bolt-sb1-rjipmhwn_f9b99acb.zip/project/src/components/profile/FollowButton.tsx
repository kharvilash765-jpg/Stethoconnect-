import { UserCheck, UserPlus } from 'lucide-react';
import { isFollowing } from '@/lib/social';
import { useStore } from '@/store/useStore';

interface FollowButtonProps {
  userId: string;
}

export function FollowButton({ userId }: FollowButtonProps) {
  const { state, dispatch } = useStore();
  if (!state.currentUserId || state.currentUserId === userId) return null;
  const following = isFollowing(state, state.currentUserId, userId);

  if (!following) {
    return (
      <button
        type="button"
        onClick={() => dispatch({ type: 'follow/toggle', userId })}
        className="group flex items-center gap-2 rounded-full bg-teal-600 px-5 py-2 text-sm font-medium text-white shadow-sm transition hover:bg-teal-700 active:scale-95"
      >
        <UserPlus className="h-4 w-4" />
        Follow
      </button>
    );
  }

  return (
    <button
      type="button"
      onClick={() => dispatch({ type: 'follow/toggle', userId })}
      aria-label="Unfollow"
      className="group flex items-center gap-2 rounded-full border border-slate-300 bg-white px-5 py-2 text-sm font-medium text-slate-800 transition hover:border-rose-300 hover:bg-rose-50 hover:text-rose-600 active:scale-95"
    >
      <UserCheck className="h-4 w-4 group-hover:hidden" />
      <span className="group-hover:hidden">Following</span>
      <span className="hidden group-hover:inline">Unfollow</span>
    </button>
  );
}
