import { Avatar } from '@/components/common/Avatar';
import { FollowButton } from '@/components/profile/FollowButton';
import type { Profile } from '@/types';

interface UserRowProps {
  profile: Profile;
}

export function UserRow({ profile }: UserRowProps) {
  return (
    <li className="flex items-center gap-3 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm transition hover:shadow-md">
      <a href={`#/profile/${profile.id}`} className="flex min-w-0 flex-1 items-center gap-3">
        <Avatar name={profile.name} seed={profile.id} />
        <span className="min-w-0">
          <span className="block truncate font-semibold text-slate-900">{profile.name}</span>
          <span className="block truncate text-sm text-slate-500">@{profile.handle}</span>
          {profile.bio && <span className="mt-0.5 block truncate text-sm text-slate-600">{profile.bio}</span>}
        </span>
      </a>
      <FollowButton userId={profile.id} />
    </li>
  );
}
