import { avatarTone, initials } from '@/lib/format';

const SIZES = {
  sm: 'h-8 w-8 text-xs',
  md: 'h-10 w-10 text-sm',
  lg: 'h-24 w-24 text-3xl sm:h-28 sm:w-28 sm:text-4xl',
} as const;

interface AvatarProps {
  name: string;
  seed: string;
  size?: keyof typeof SIZES;
}

export function Avatar({ name, seed, size = 'md' }: AvatarProps) {
  return (
    <div
      aria-hidden="true"
      className={`flex shrink-0 select-none items-center justify-center rounded-full font-semibold text-white ring-2 ring-white ${avatarTone(seed)} ${SIZES[size]}`}
    >
      {initials(name)}
    </div>
  );
}
