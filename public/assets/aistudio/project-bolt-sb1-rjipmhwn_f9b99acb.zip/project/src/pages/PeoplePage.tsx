import { useState } from 'react';
import { Search } from 'lucide-react';
import { UserRow } from '@/components/profile/UserRow';
import { useStore } from '@/store/useStore';

export function PeoplePage() {
  const { state } = useStore();
  const [query, setQuery] = useState('');
  const term = query.trim().toLowerCase().replace(/^@/, '');

  const others = state.profiles.filter((p) => p.id !== state.currentUserId);
  const matches = term
    ? others.filter((p) => p.name.toLowerCase().includes(term) || p.handle.includes(term))
    : others;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold leading-[1.2] text-slate-900">People</h1>
        <p className="mt-1 text-sm text-slate-600">Discover members and follow the ones you want to learn from.</p>
      </div>

      <label className="relative block">
        <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search by name or @username"
          aria-label="Search people"
          className="w-full rounded-full border border-slate-300 bg-white py-2.5 pl-11 pr-4 text-slate-900 placeholder:text-slate-400 focus:border-teal-500 focus:outline-none focus:ring-4 focus:ring-teal-500/15"
        />
      </label>

      {matches.length === 0 ? (
        <p className="rounded-2xl border border-dashed border-slate-300 bg-white px-6 py-10 text-center text-sm text-slate-600">
          {others.length === 0 ? 'No other members yet. Invite a friend to join.' : 'No one matches your search.'}
        </p>
      ) : (
        <ul className="space-y-3">
          {matches.map((p) => (
            <UserRow key={p.id} profile={p} />
          ))}
        </ul>
      )}
    </div>
  );
}
