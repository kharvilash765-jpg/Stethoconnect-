import { useState } from 'react';
import { LogOut, Pencil, Settings } from 'lucide-react';
import { PostFeed } from '@/components/feed/PostFeed';
import { EditProfileModal } from '@/components/profile/EditProfileModal';
import { FollowButton } from '@/components/profile/FollowButton';
import { ProfileHeader } from '@/components/profile/ProfileHeader';
import { getProfileStats } from '@/lib/social';
import { useStore } from '@/store/useStore';

interface ProfilePageProps {
  userId: string;
}

export function ProfilePage({ userId }: ProfilePageProps) {
  const { state, dispatch } = useStore();
  const [editing, setEditing] = useState(false);
  const profile = state.profiles.find((p) => p.id === userId);

  if (!profile) {
    return (
      <div className="animate-fade-up rounded-2xl border border-dashed border-slate-300 bg-white px-6 py-12 text-center">
        <p className="font-semibold text-slate-900">Profile not found</p>
        <a href="#/" className="mt-4 inline-block text-sm font-medium text-teal-700 hover:underline">
          Back to home
        </a>
      </div>
    );
  }

  const isOwn = state.currentUserId === profile.id;
  const stats = getProfileStats(state, profile.id);
  const posts = state.posts.filter((p) => p.authorId === profile.id);

  const ownActions = (
    <>
      <button
        type="button"
        onClick={() => setEditing(true)}
        className="flex items-center gap-2 rounded-full border border-slate-300 bg-white px-5 py-2 text-sm font-medium text-slate-800 transition hover:bg-slate-50 active:scale-95"
      >
        <Pencil className="h-4 w-4" />
        Edit profile
      </button>
      <button
        type="button"
        onClick={() => dispatch({ type: 'session/set', userId: null })}
        className="flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium text-slate-600 transition hover:bg-slate-100 hover:text-slate-900"
      >
        <LogOut className="h-4 w-4" />
        Log out
      </button>
    </>
  );

  return (
    <div className="space-y-6">
      <div className="relative">
        <ProfileHeader profile={profile} stats={stats} actions={isOwn ? ownActions : <FollowButton userId={profile.id} />} />
        {isOwn && (
          <a
            href="#/settings"
            aria-label="Settings"
            className="absolute right-3 top-3 rounded-full p-2 text-slate-500 transition hover:bg-slate-100 hover:text-slate-900 sm:right-5 sm:top-5"
          >
            <Settings className="h-5 w-5" />
          </a>
        )}
      </div>

      <div>
        <h2 className="mb-4 text-base font-semibold text-slate-900">
          {isOwn ? 'Your posts' : `Posts by ${profile.name}`}
        </h2>
        <PostFeed
          posts={posts}
          emptyTitle={isOwn ? 'You have not posted yet' : 'No posts yet'}
          emptyText={isOwn ? 'Share your first post from the home page.' : 'Check back later for new posts.'}
        />
      </div>

      {editing && <EditProfileModal onClose={() => setEditing(false)} />}
    </div>
  );
}
