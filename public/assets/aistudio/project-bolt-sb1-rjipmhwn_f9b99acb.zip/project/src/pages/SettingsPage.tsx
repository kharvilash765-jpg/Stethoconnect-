import { ChevronRight, HeartPulse, Info, Scale, Shield, Users, type LucideIcon } from 'lucide-react';
import { LEGAL_DOCUMENTS } from '@/content/legalPages';

const LEGAL_ICONS: Record<string, LucideIcon> = {
  disclaimer: Info,
  'privacy-policy': Shield,
  'terms-and-conditions': Scale,
  'patient-privacy-policy': HeartPulse,
  'community-guidelines': Users,
};

export function SettingsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold leading-[1.2] text-slate-900">Settings</h1>
        <p className="mt-1 text-sm text-slate-600">Review the rules and policies that apply to Medicoshare.</p>
      </div>

      <section className="animate-fade-up overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
        <h2 className="border-b border-slate-100 px-5 py-4 text-sm font-semibold text-slate-900">Legal & Policies</h2>
        <ul className="divide-y divide-slate-100">
          {LEGAL_DOCUMENTS.map((doc) => {
            const Icon = LEGAL_ICONS[doc.slug];
            return (
              <li key={doc.slug}>
                <a
                  href={`#/legal/${doc.slug}`}
                  className="group flex items-center gap-4 px-5 py-4 transition hover:bg-teal-50/60"
                >
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-teal-50 text-teal-700 transition group-hover:bg-teal-100">
                    <Icon className="h-5 w-5" />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-sm font-medium text-slate-900">{doc.title}</span>
                    <span className="block truncate text-sm text-slate-500">{doc.description}</span>
                  </span>
                  <ChevronRight className="h-5 w-5 shrink-0 text-slate-400 transition group-hover:translate-x-0.5 group-hover:text-teal-700" />
                </a>
              </li>
            );
          })}
        </ul>
      </section>
    </div>
  );
}
