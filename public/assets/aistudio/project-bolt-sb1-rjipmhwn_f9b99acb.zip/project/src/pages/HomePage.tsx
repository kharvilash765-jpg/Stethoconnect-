import { Composer } from '@/components/feed/Composer';
import { PostFeed } from '@/components/feed/PostFeed';
import { useStore } from '@/store/useStore';

export function HomePage() {
  const { state } = useStore();

  return (
    <div className="space-y-6">
      <Composer />
      <PostFeed
        posts={state.posts}
        emptyTitle="No posts yet"
        emptyText="Be the first to share a health tip, question or experience with the community."
      />
    </div>
  );
}
