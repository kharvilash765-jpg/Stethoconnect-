import { ArrowLeft } from 'lucide-react';
import { PostCard } from '@/components/feed/PostCard';
import { CommentSection } from '@/components/comments/CommentSection';
import { useStore } from '@/store/useStore';

interface PostPageProps {
  postId: string;
}

export function PostPage({ postId }: PostPageProps) {
  const { state } = useStore();
  const post = state.posts.find((p) => p.id === postId);

  if (!post) {
    return (
      <div className="animate-fade-up rounded-2xl border border-dashed border-slate-300 bg-white px-6 py-12 text-center">
        <p className="font-semibold text-slate-900">This post is no longer available</p>
        <a href="#/" className="mt-4 inline-block text-sm font-medium text-teal-700 hover:underline">
          Back to home
        </a>
      </div>
    );
  }

  return (
    <div>
      <a
        href="#/"
        className="mb-4 inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-sm font-medium text-slate-600 transition hover:bg-slate-100 hover:text-slate-900"
      >
        <ArrowLeft className="h-4 w-4" />
        Back
      </a>
      <PostCard post={post} />
      <CommentSection postId={post.id} />
    </div>
  );
}
