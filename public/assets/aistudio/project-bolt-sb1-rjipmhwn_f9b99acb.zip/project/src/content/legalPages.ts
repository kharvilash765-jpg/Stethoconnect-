export interface LegalSection {
  heading: string;
  paragraphs: string[];
}

export interface LegalDocument {
  slug: string;
  title: string;
  description: string;
  summary: string;
  sections: LegalSection[];
}

export const LEGAL_LAST_UPDATED = '1 November 2026';

export const FOUNDERS = 'Praveen koli and Monu Lakshakar';

export const LEGAL_DOCUMENTS: LegalDocument[] = [
  {
    slug: 'disclaimer',
    title: 'Disclaimer',
    description: 'What Medicoshare is, and what it is not',
    summary:
      'Medicoshare is a community platform for sharing health experiences and information. It does not provide medical advice, diagnosis or treatment.',
    sections: [
      {
        heading: 'Who runs Medicoshare',
        paragraphs: [
          `Medicoshare is founded and operated by ${FOUNDERS}. Questions about this disclaimer can be raised through the app.`,
        ],
      },
      {
        heading: 'Not medical advice',
        paragraphs: [
          'All posts, comments and other content on Medicoshare are written by members and are for general information and discussion only. They do not replace advice from a qualified doctor or other healthcare professional.',
          'Never delay seeking professional care, or stop or change a prescribed treatment, because of something you read on Medicoshare.',
        ],
      },
      {
        heading: 'No doctor-patient relationship',
        paragraphs: [
          'Using Medicoshare does not create a doctor-patient or other healthcare relationship with anyone on the platform, including members who describe themselves as clinicians.',
        ],
      },
      {
        heading: 'Emergencies',
        paragraphs: [
          'Medicoshare is not suitable for urgent or emergency situations. If you or someone else may be in danger, contact your local emergency number or go to the nearest hospital immediately.',
        ],
      },
      {
        heading: 'Accuracy of content',
        paragraphs: [
          'We do not guarantee that any content is accurate, complete or up to date. Members are responsible for the content they post, and we rely on reports from the community to flag problems.',
        ],
      },
    ],
  },
  {
    slug: 'privacy-policy',
    title: 'Privacy Policy',
    description: 'How we handle your account and activity data',
    summary:
      'This policy explains what information Medicoshare stores about you, how it is used, and the choices you have over your data.',
    sections: [
      {
        heading: 'Who is responsible for your data',
        paragraphs: [
          `Medicoshare is operated by ${FOUNDERS}, who are responsible for how information in the app is handled.`,
        ],
      },
      {
        heading: 'Information we store',
        paragraphs: [
          'When you create a profile, we store your name, username and bio. When you use the app, we also store the posts, images, comments, reactions, follows and reports you create, and the view counts that power post reach.',
          'At present, this information is stored in the browser on the device you use. Clearing your browser data will remove it.',
        ],
      },
      {
        heading: 'How we use information',
        paragraphs: [
          'We use this information to run the features you use, such as showing your posts to others, displaying your profile and reach, and reviewing reports. We do not sell your personal information.',
        ],
      },
      {
        heading: 'What other members can see',
        paragraphs: [
          'Your name, username, bio, posts, comments and follower counts are visible to all members of Medicoshare. Please think carefully before sharing personal details publicly.',
        ],
      },
      {
        heading: 'Your choices',
        paragraphs: [
          'You can edit your name and bio, delete your own posts and comments, and stop following anyone at any time. You can also clear your browser data to remove everything stored by the app.',
        ],
      },
      {
        heading: 'Changes to this policy',
        paragraphs: [
          'We may update this policy as the app grows, for example when storage moves to a cloud service. We will update the date at the top of this page when we do.',
        ],
      },
    ],
  },
  {
    slug: 'terms-and-conditions',
    title: 'Terms & Conditions',
    description: 'The rules for using Medicoshare',
    summary:
      'By using Medicoshare, you agree to these terms. Please read them carefully, especially the parts about your content and acceptable behaviour.',
    sections: [
      {
        heading: 'Who we are',
        paragraphs: [
          `Medicoshare is founded and operated by ${FOUNDERS}. These terms form an agreement between you and them.`,
        ],
      },
      {
        heading: 'Eligibility and accounts',
        paragraphs: [
          'You must be at least 13 years old to use Medicoshare. You are responsible for the activity on your profile and for keeping your device secure.',
          'Your username must not impersonate another person, and you must not claim qualifications or credentials you do not hold.',
        ],
      },
      {
        heading: 'Your content',
        paragraphs: [
          'You keep ownership of what you post. By posting, you allow Medicoshare to display your content to other members as part of the service. You confirm that you have the right to share anything you upload.',
        ],
      },
      {
        heading: 'Acceptable use',
        paragraphs: [
          'You agree not to harass others, post spam or advertising, share content that is illegal, hateful or sexually explicit, or use the platform to mislead people about health. The Community Guidelines describe these rules in more detail.',
        ],
      },
      {
        heading: 'Moderation and reports',
        paragraphs: [
          'Members can report posts. We may hide or remove content and limit or end accounts that break these terms. We will try to act fairly, but we cannot review every post in advance.',
        ],
      },
      {
        heading: 'Limitation of responsibility',
        paragraphs: [
          'Medicoshare is provided as is. To the fullest extent permitted by law, we are not responsible for decisions you make based on content from other members, or for losses arising from your use of the app.',
        ],
      },
      {
        heading: 'Changes to these terms',
        paragraphs: [
          'We may update these terms from time to time. Continued use of Medicoshare after an update means you accept the revised terms.',
        ],
      },
    ],
  },
  {
    slug: 'patient-privacy-policy',
    title: 'Patient Privacy Policy',
    description: 'How to protect patient confidentiality when you share',
    summary:
      'Health information is sensitive. This policy explains how to share medical experiences on Medicoshare without exposing identifiable patients.',
    sections: [
      {
        heading: 'Do not identify patients',
        paragraphs: [
          'Do not post names, photos, contact details, addresses, ID numbers, or medical record numbers of patients, including yourself if you prefer to stay private. Avoid details such as exact dates, locations or workplaces that could identify someone.',
          'Crop or blur images to remove faces, name tags, wristbands and any other identifying marks before you upload them.',
        ],
      },
      {
        heading: 'Consent before sharing',
        paragraphs: [
          'If you share a story about someone else, make sure they have agreed to it. Clinicians must follow their professional confidentiality obligations and the rules of their medical council or regulator before sharing any patient information.',
        ],
      },
      {
        heading: 'Do not upload medical records',
        paragraphs: [
          'Medicoshare is not a medical record system. Do not upload lab reports, prescriptions, scans or discharge summaries that have not been fully de-identified.',
        ],
      },
      {
        heading: 'Removal requests',
        paragraphs: [
          'If you believe content exposes your identity or a patient you represent, report the post using the Report option. We will review it and remove content that breaches this policy.',
        ],
      },
    ],
  },
  {
    slug: 'community-guidelines',
    title: 'Community Guidelines',
    description: 'How we keep Medicoshare respectful and useful',
    summary:
      'Medicoshare works best when people feel safe to ask questions and share experiences. These guidelines set out what that looks like in practice.',
    sections: [
      {
        heading: 'Be respectful',
        paragraphs: [
          'Disagree with ideas, not people. Personal attacks, insults, threats, discrimination and bullying are not allowed in posts, comments or profiles.',
        ],
      },
      {
        heading: 'Share accurate health information',
        paragraphs: [
          'Share what you know, mention your sources where you can, and say clearly when you are unsure or sharing a personal experience. Do not promote unproven treatments, miracle cures or products that could cause harm.',
        ],
      },
      {
        heading: 'Keep content appropriate',
        paragraphs: [
          'Avoid graphic images of injuries, surgery or bodies, and do not post sexual or exploitative content. Use content warnings in your text when a post is sensitive.',
        ],
      },
      {
        heading: 'No spam or self-promotion',
        paragraphs: [
          'Do not post repeated content, scams, or advertisements for drugs, supplements, clinics or services without disclosure. Occasional, relevant links that help the discussion are fine.',
        ],
      },
      {
        heading: 'Report problems',
        paragraphs: [
          'Use the Report option on any post that breaks these guidelines. Reports help us keep the community safe. Members who repeatedly break these guidelines may lose access to the platform.',
        ],
      },
    ],
  },
];
