import { createContext, type Dispatch } from 'react';
import type { Action } from '@/lib/appReducer';
import type { AppState } from '@/types';

export interface StoreContextValue {
  state: AppState;
  dispatch: Dispatch<Action>;
  storageError: boolean;
}

export const StoreContext = createContext<StoreContextValue | null>(null);
