import { useEffect, useReducer, useState, type ReactNode } from 'react';
import { appReducer } from '@/lib/appReducer';
import { loadState, saveState } from '@/lib/storage';
import { StoreContext } from '@/store/storeContext';

export function StoreProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(appReducer, undefined, loadState);
  const [storageError, setStorageError] = useState(false);

  useEffect(() => {
    setStorageError(!saveState(state));
  }, [state]);

  return (
    <StoreContext.Provider value={{ state, dispatch, storageError }}>{children}</StoreContext.Provider>
  );
}
